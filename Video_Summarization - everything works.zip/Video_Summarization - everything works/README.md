# Video Summarizer

This project summarizes YouTube videos or user-uploaded videos using Whisper for transcription and BART for summarization.

## How to Run

1. Install dependencies:
   ```bash
   pip install -r requirements.txt